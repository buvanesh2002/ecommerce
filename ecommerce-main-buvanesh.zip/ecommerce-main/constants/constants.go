package constants

const ConnectionString = "mongodb+srv://kishore:keepkishore@cluster0.vgu9tbs.mongodb.net/"

// const ConnectionString = "mongodb+srv://guru:guru@shoppingsite.b4awy46.mongodb.net/"
const Port = ":5002"
const DatabaseName = "Ecommerce"
const SecretKey = "your-secret-key"
